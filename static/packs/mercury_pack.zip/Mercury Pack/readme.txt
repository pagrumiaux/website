Thanks for downloading this Microfreak preset pack.

===== CONTENT =====
4 lead
2 bass
1 brass
1 SFX
6 pad
1 percussion
1 sequence

===== HOW TO INSTALL =====

1. Open the MIDI Control Center software (available on the Arturia website)
2. Under "Device", choose "MicroFreak"
3. Connect your MicroFreak to your computer via USB and turn it on. The connection should be done between the software and your MicroFreak
5. Under the "Selection" tab and the "List View tab", click on "Import" then "Import New Project".
6. Open the *.mfprojz file
7. You can now drag and drop presets of this pack in your MicroFreak preset list on the right! (beware not to erase already existing presets)

Enjoy :)